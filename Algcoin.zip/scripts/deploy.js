async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with account:", deployer.address);

  const Algcoin = await ethers.getContractFactory("Algcoin");
  const token = await Algcoin.deploy();
  await token.deployed();

  console.log("Algcoin deployed to:", token.address);
  console.log("Total supply:", (await token.totalSupply()).toString());
}

main().then(() => process.exit(0)).catch(error => {
  console.error(error);
  process.exit(1);
});
