# Algcoin

Algcoin — ERC-20 token contract.

- **Name:** Algcoin
- **Symbol:** ALG
- **Total supply:** 100,000,000 (with 18 decimals)

## Local setup

```bash
npm install
npx hardhat compile
npx hardhat node
npx hardhat run scripts/deploy.js --network localhost
```
